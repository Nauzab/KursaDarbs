<html>


<?php
    # Veidojam savienojumu ar savu serveri un datu bāzi
$d = mysqli_connect('localhost','worldread','worldreadPaSS','pasakums') or die('Nevaru pievienoties datubāzei');
$chs=mysqli_set_charset($d, "utf8");

$query = "SELECT Distinct pilseta FROM Adrese  WHERE ValstsID = '".$_POST["ID"]."'";
$result = mysqli_query($d,$query);
?>

<option> Select city</option>

<?php 
    while($rs = mysqli_fetch_array($result)){
        ?>
        <option value = "<?php echo $rs["ID"]; ?>"> <?php echo $rs["pilseta"];?> </option>
        <?php 
    }
    ?>
</html>