-- MySQL dump 10.13  Distrib 5.7.24, for Linux (x86_64)
--
-- Host: localhost    Database: pasakums
-- ------------------------------------------------------
-- Server version	5.7.24-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pasakums`
--

DROP TABLE IF EXISTS `pasakums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pasakums` (
  `pasakumaID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pilseta` varchar(100) DEFAULT NULL,
  `vieta` varchar(100) DEFAULT NULL,
  `datums` varchar(30) DEFAULT NULL,
  `laiks` varchar(20) DEFAULT NULL,
  `norise` varchar(100) DEFAULT NULL,
  `MaksaNoEuro` double DEFAULT NULL,
  `PersonasID` int(11) DEFAULT NULL,
  PRIMARY KEY (`pasakumaID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pasakums`
--

LOCK TABLES `pasakums` WRITE;
/*!40000 ALTER TABLE `pasakums` DISABLE KEYS */;
INSERT INTO `pasakums` VALUES (1,'Ventspils','Ventspils Ratslaukuma','01.12.18','17.00',' Pilsetas galvenas Ziemassvetku egles iedegsana.',NULL,2),(2,'Ventspils','Ventspils kulturas centra','01.12.18','15.00','Koncerts \'Ledus puku balle\' ',2,2),(3,'Ventspils','Juras varti','01.12.18','15.00','Deju uzvedums \'Baltais ziemas stasts\' ',2,2),(4,'Riga','Arena Riga','01.12.18','19.00','LNK Fight Night vol.10 profesionalas cinas MMA, boksa un Kick-boksa',12.6,1),(5,'Riga','Latvijas nacionala opera','02.12.18','15.00','Opera \'MADAMA BUTTERFLY\' ',6,1),(6,'Riga','Latvijas nacionala opera','25.01.19','19.00','Opera \'MADAMA BUTTERFLY\' ',7,1),(7,'Liepaja','Tirdzniecibas nams Kurzeme, 1.stava foaje','05.12.18','10.00','POP UP Ziemassvetku tirgus liepaja 2018',NULL,4),(8,'Liepaja','Liepajas Latviesu biedribas nams','12.12.18','12.00','Bernu teatra izrade \'Engeli varaviksnes krasa\'',1,4),(9,'Jelgava','Jelgavas Sv.Trisvienibas baznicas tornis, Akademijas iela 1, Jelgava','14.12.18','19.00','Annijas Putninas koncerts \'Zem zvaigznotas debess\' ',NULL,5),(10,'Jelgava','Jelgavas pils','15.12.18','20.00','Ziemassvetku balle Jelgavas pili',35,5);
/*!40000 ALTER TABLE `pasakums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personas`
--

DROP TABLE IF EXISTS `personas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personas` (
  `PersonasID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Uzvards` varchar(255) DEFAULT NULL,
  `Vards` varchar(225) DEFAULT NULL,
  `Epasts` varchar(225) DEFAULT NULL,
  PRIMARY KEY (`PersonasID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personas`
--

LOCK TABLES `personas` WRITE;
/*!40000 ALTER TABLE `personas` DISABLE KEYS */;
INSERT INTO `personas` VALUES (1,'Zemnieks',' Janis',' Zemnieksjanis@gamail.com'),(2,'Austris','Peteris',' PetersiAustris@gamail.com'),(3,'Kolokovs','Peteris',' Kolokovs@gamail.com'),(4,'Buks','Martins',' Martins.buks@gamail.com'),(5,'Sprogis','Edmunds',' Edza@gamail.com');
/*!40000 ALTER TABLE `personas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-11-27 12:50:36
