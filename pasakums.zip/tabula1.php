<?php   

$d = mysqli_connect('localhost','worldread','worldreadPaSS','pasakums') or die('Nevaru pievienoties datubāzei');
$chs=mysqli_set_charset($d, "utf8");

?>


<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Tabulu f-jas demo </title>
<style>

body {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #ddd;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2;}
tr:hover {background-color: #ddd;}

th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
}

</style>
</head>
<body>
<h1>Multi tabulu f-ja </h1>

<?php

function tabula($sql_res) {
$first = true;
echo "<center><table class=\"schedule\">";
while ($row = mysqli_fetch_assoc($sql_res)) {
    if ($first) {
        echo "<tr>";
        foreach ($row as $k=>$v) {
            echo "<th>$k</th>";
        }
        echo "</tr>".PHP_EOL;
        $first = false;
    }
    echo "<tr>";
        foreach ($row as $v) {
            echo "<td>$v</td>";
        }
        echo "</tr>".PHP_EOL;
}
echo "</table></center>";


/* izprinte datu rindas skaitu*/

$row_cnt = mysqli_num_rows($sql_res);
printf("<br><left>Result set has <b>%d</b> rows. </left>\n", $row_cnt);
/* close result set */
mysqli_free_result($sql_res);
}

# Veidojam savienojumu ar savu serveri un datu bāzi

?>


<?php

/* Nākamais bloks */

echo "<h3>Pasakuma tabula </h3>";

$sql="Select * FROM Pasakums ;";
echo "<!-- $sql -->";
$sql_res = mysqli_query($d,$sql) or die("<h1>".mysqli_error()."</h1>");
tabula($sql_res);

echo "<h3>Personas Tabula </h3>";

$sql="Select * FROM Lietotajs;";
echo "<!-- $sql -->";
$sql_res = mysqli_query($d,$sql) or die("<h1>".mysqli_error()."</h1>");
tabula($sql_res);



mysqli_close();
?>

</body>
</html>
