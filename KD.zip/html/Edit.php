<?php
# Veidojam savienojumu ar savu serveri un datu bāzi
$d = mysqli_connect('localhost','worldread','worldreadPaSS','pasakums') or die('Nevaru pievienoties datubāzei');
$chs=mysqli_set_charset($d, "utf8");
    
    
        if(isset($_GET['edit'])){

        
            $id = $_GET['edit'];
            $sql="SELECT * FROM PasakumaSkats WHERE ID = '$id' ";
            $res = mysqli_query($d,$sql);
            $row = mysqli_fetch_array($res);
         } 

         if($_POST["valsts"] || $_POST["pilseta"] || $_POST["adrese"] || $_POST["norise"] || $_POST["datums"]
            || $_POST["laiks"] || $_POST["ieeja"] || $_POST["id"]){
         if($_POST['Update']){

            //Set veriables to input values by input names;
   $pilseta = $_POST["pilseta"];
   $adrese = $_POST["adrese"];
   $norise = $_POST["norise"];
   $datums = $_POST["datums"];
   $laiks = $_POST["laiks"];
   $ieeja = $_POST["ieeja"];

   $result1 = mysqli_query($d,"SELECT * FROM Adrese WHERE Pilseta = '$pilseta' ");
   $count1 = mysqli_num_rows($result1);
        if($count1 >= 1){
            $sql1 = "UPDATE Pasakums SET Norise = '$norise', Datums = '$datums', Laiks ='$laiks', Ieeja = '$ieeja' WHERE ID = $id ";
            $sql2 = "UPDATE Adrese SET Pilseta = '$pilseta', Adrese = '$adrese' WHERE ID =(SELECT AdresesID FROM Pasakums WHERE ID = $id)";
            $sql3 = "UPDATE Adrese SET PilsetasID = GetPID('$pilseta') WHERE ID =(SELECT AdresesID FROM Pasakums WHERE ID = $id)";
            
            if( mysqli_query($d, $sql1) && mysqli_query($d, $sql2) && mysqli_query($d, $sql3) ){

            }
         
        
        //If post is submitted without input then else section sends erro message.
         }
         else{
            $sql1 = "UPDATE Pasakums SET Norise = '$norise', Datums = '$datums', Laiks ='$laiks', Ieeja = '$ieeja' WHERE ID = $id ";
            $sql2 = "UPDATE Adrese SET Pilseta = '$pilseta', Adrese = '$adrese' WHERE ID =(SELECT AdresesID FROM Pasakums WHERE ID = $id)";
            $sql3 = "UPDATE Adrese SET PilsetasID = PID() WHERE ID =(SELECT AdresesID FROM Pasakums WHERE ID = $id)";
            
            if( mysqli_query($d, $sql1) && mysqli_query($d, $sql2) && mysqli_query($d, $sql3) ){

            }

         }
             
         header("Location: pasakums.php");   
           }
        }
        if($_POST['Delete']){
            $sql = "DELETE FROM Pasakums WHERE ID = $id ";
            $sql1 = "DELETE FROM Adrese WHERE ID = (SELECT AdresesID FROM Pasakums WHERE ID = $id)";
            if( mysqli_query($d, $sql) ){
            header("Location: pasakums.php");
            }
        }

?>
<html>
<body background="images.jpeg">
<link rel="stylesheet" href="pasakums.css" type="text/css"> 
<title> Edit </title>
<form action = "" method= "POST">

Valsts: <input type = "text" name = "valsts" value = "<?php echo $row[1]; ?>"><br>
Pilseta: <input type = "text" name = "pilseta" value = "<?php echo $row[2]; ?>"><br>
Norise: <input type = "text" name = "norise" value = "<?php echo htmlspecialchars($row[3]) ; ?>"><br>
Datums: <input type = "text" name = "datums" value = "<?php echo $row[4] ; ?>"><br>
Laiks: <input type = "text" name = "laiks" value = "<?php echo $row[5] ; ?>"><br>
Ieeja: <input type = "text" name = "ieeja" value = "<?php echo $row[6] ; ?>"><br>
Adrese: <input type = "text" name = "adrese" value = "<?php echo $row[7] ; ?>"><br>
<input type = "submit" name = "Update" value = "Update" >
<input type = "submit" onclick = "return confirm('Are you sure you want to DELETE event?')" name = "Delete" value = "Delete">
<br>
<div id = "Login" >           
           <a href="pasakums.php" style = 'color:blue;'>sakums</a>
               
           </div>
</form>
<h1> Pasakumu Ievietojis </h1>
</body>
</html>

<?php
function tabula($sql_res) {
$first = true;
echo "<center><table class=\"schedule\">";
while ($row = mysqli_fetch_assoc($sql_res)) {
    if ($first) {
        echo "<tr>";
        foreach ($row as $k=>$v) {
            echo "<th>$k</th>";
            
        }
        echo "</tr>".PHP_EOL;
        $first = false;
    }
    echo "<tr>";
        foreach ($row as $v) {
            echo "<td>$v</td>";
            
        }
        
        echo "</tr>".PHP_EOL;
        
}
echo "</table></center>";

$row_cnt = mysqli_num_rows($sql_res);

/* close result set */
mysqli_free_result($sql_res);
}
?>
<?php
$sql="SELECT l.Vards , l.Uzvards , k.Epasts, k.TelefonaNr FROM Lietotajs l JOIN Kontakti k JOIN Pasakums p 
        WHERE (l.ID = k.LietotajaID AND p.LietotajaID = l.ID) AND p.ID = $id GROUP BY l.ID";
echo "<!-- $sql -->";
$sql_res = mysqli_query($d,$sql) or die("<h1>".mysqli_error()."</h1>");
tabula($sql_res);
?>