<?php
    session_start();
    $d = mysqli_connect('localhost','worldread','worldreadPaSS','pasakums') or die('Nevaru pievienoties datubāzei');
    $chs=mysqli_set_charset($d, "utf8");


   
    if (isset($_POST['email']) and isset($_POST['numurs'])){
     $username = $_POST['email'];
    $numurs = $_POST['numurs'];
    // Include config file

    $sql = "SELECT * FROM Kontakti WHERE Epasts = '$username' AND TelefonaNr = '$numurs'" ;
    $result = mysqli_query($d,$sql) ;
    $count = mysqli_num_rows($result);
    if($count >=1 ){
        $_SESSION['numurs'] = $numurs; 

    header("Location: izveide.php");
    }else{
        echo "invalid Email or numurs";
    }

}


?>


<html>

<body background="images.jpeg">

<head>
    <meta charset="UTF-8">
    <title > Pieslēgties </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
    </style>
   <h1>Pieslēgšanās</h1>

            <form actioc = "" method = "POST">
            <table>
            <tr>
            <td>Epasts:</td><td><input name="email" type="email" ></td>
            </tr>

            <tr>
            <br>
            <td>Telefona numurs :</td><td><input name="numurs" type="text" ></td>
            </tr>
        
            </form>
            </table>
            <input type="submit" value="Pieslēgties" text-align:center;/>
                 
         </div>
             
      </div>
         
   </div> <div id = "Login" >
           
            
            <a href="pasakums.php">Sākums</a>
                <br>
            
            <a href="register.php">Registret lietotaju</a>
                
            </div>

</body>
</html></div>
           