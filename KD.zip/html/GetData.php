<html>


<?php
    # Veidojam savienojumu ar savu serveri un datu bāzi
$d = mysqli_connect('localhost','worldread','worldreadPaSS','pasakums') or die('Nevaru pievienoties datubāzei');
$chs=mysqli_set_charset($d, "utf8");


function fill_brand1($d)  
{  
     $output = '';  
     $sql = "SELECT * FROM Pasakums p Join Adrese a WHERE p.ValstsID = '".$_POST["ID"]."' AND p.AdresesID = a.ID ORDER BY p.ID";  
     $result = mysqli_query($d, $sql);  
     while($row = mysqli_fetch_array($result))  
     {  
         
          $output .= '<option value="'.$row["ID"].'">'.$row["Datums"].'</option>';  
     }  
     return $output;  
}  


function fill_product1($d)  
{  
    
     $sql = "SELECT * FROM Pasakums ";  
     $result = mysqli_query($d, $sql);  
    
}  
?>

<option> Select date</option>
<?php echo fill_brand1($d); ?> 
</html>