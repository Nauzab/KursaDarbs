  
  <?php
# Veidojam savienojumu ar savu serveri un datu bāzi
$d = mysqli_connect('localhost','worldread','worldreadPaSS','pasakums') or die('Nevaru pievienoties datubāzei');
$chs=mysqli_set_charset($d, "utf8");


  
#Pilsetas izvele;
$query = "SELECT DISTINCT pilseta FROM Adrese;";
$result2 = mysqli_query($d,$query);


#Datuma izvele;
$query = "SELECT DISTINCT datums FROM Pasakums;";
$result3 = mysqli_query($d,$query);
?>


  <html>
  <body>
  
  <!--Izveido pilsetas izveli -->
  Pilseta <select >
                <option value = "">select city </option>    
                <?php while($row1 = mysqli_fetch_array($result2)):;?>
                    
                    <option value = ""> <?php echo $row1[0]; ?> </option>
                    <?php endwhile ?>
                        
                </select>


                <!--Izveido Datuma izveli -->
                Datums<select >

                <?php while($row1 = mysqli_fetch_array($result3)):;?>
                    
                    <option> <?php echo $row1[0]; ?> </option>
                    <?php endwhile ?>
                        
                </select>

</body>
 </html>