<?php
session_start();
unset($_SESSION['numurs']);
session_destroy();

header("Location: login.php");
exit;
?>
