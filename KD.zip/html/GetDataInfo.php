
<?php  

# Veidojam savienojumu ar savu serveri un datu bāzi
$connect = mysqli_connect('localhost','worldread','worldreadPaSS','pasakums') or die('Nevaru pievienoties datubāzei');
$chs=mysqli_set_charset($connect, "utf8");


//load_data.php  

$output = '';  
if(isset($_POST["brand_id"]))  
{  
  if($_POST["brand_id"] != '')  
  {  
       $sql = "SELECT * FROM Pasakums p Join Adrese a WHERE p.ID = '".$_POST["brand_id"]."' AND a.ID = p.AdresesID";  
  }  
  else  
  {  
       $sql = "SELECT * FROM Pasakums p Join Adrese a WHERE p.ID = '".$_POST["brand_id"]."' AND a.ID = p.AdresesID ";  
  }  
  $result = mysqli_query($connect, $sql);  
  while($row = mysqli_fetch_array($result))  
  {  
       $output .= '<div class=\"schedule\"><div style="border:1px solid #ccc; padding:20px; margin-bottom:20px; text-align: center; font-size: 20px;">'.$row["Norise"].'/'.$row["Laiks"].'/'.$row["Pilseta"].'/'.$row["Adrese"].'/ '.$row["Ieeja"].'</div></div>';  
  }  
  echo $output;  
}  
?>  